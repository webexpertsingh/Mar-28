exports.myBands = {
  punk: "Green Day",
  rap: "Run DMC",
  classic: "Led Zeppelin"
};